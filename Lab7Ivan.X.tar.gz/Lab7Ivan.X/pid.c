#include "pid.h"
#include "servos.h"
#include "touchscreen.h"
#include "mymaths.h"
#include "calibrate.h"
#include "lcd.h"

// Kp: 0.0005, 0.0004
//static const float xKp = 0.0005, xKd = -0.1, xKi = 0;// 0.0015, 0.00001, 0.001 for working for any one-dimension
//static const float yKp = 0.0004, yKd = -0.08, yKi = 0;

static const float xKp = 1, xKd = -300, xKi = -0.001; //xKi = -0.00008; //xKi = -0.001;// 0.0015, 0.00001, 0.001 for working for any one-dimension
static const float yKp = 1, yKd = -300, yKi = 0; //yKi = -0.001;

//static const float xKp = 0, xKd = 0, xKi = -0.001;// 0.0015, 0.00001, 0.001 for working for any one-dimension
//static const float yKp = 0, yKd = 0, yKi = -0.001;

static volatile float x_errors[1024];
volatile float x_error_sum = 0;

static volatile float y_errors[1024];
volatile float y_error_sum = 0;

volatile int16_t servo_action[2]; 

static void do_pid_for_axis(uint16_t axis, float position, float target, 
        float* errors, int errorslen, float* error_sum,
        float Kp, float Kd, float Ki) {
    int i;
    
    uint16_t* cal_data = touchscreen_calibration_data(axis);
    position = clamp(position, (float) cal_data[0], (float) cal_data[1]);
    
    *error_sum = *error_sum - errors[errorslen - 1];
    for (i = errorslen - 1; i > 0; i--) {
        errors[i] = errors[i - 1];
    }
    errors[0] = (position - target) / absf((float) cal_data[0] - (float) cal_data[1]);
    *error_sum = *error_sum + errors[0];
    
    float action = Kp * errors[0] - Kd * ((errors[0] - errors[1]) / 20) - Ki * (*error_sum) * 20;
    action = clamp(action, -1, 1);
    
    int16_t* servo_cal_data = servos_calibration_data(axis);
    float servo_min = (float) -servo_cal_data[0];
    float servo_max = (float) -servo_cal_data[1];
    
    servo_action[axis] = -(((action + 1) / 2) * (servo_max - servo_min) + servo_min);
    
    /*
    servo_set_duty(axis, (int16_t) real_action);
    
    reading = y[0];
    reading_raw = x[0];
    error = errors[0];
    */
}

void do_pid_calculation(uint8_t axis) {
    if (axis == TOUCH_X_AXIS) {
        do_pid_for_axis(TOUCH_X_AXIS, touchscreen_read_x(), (float) touchscreen_calibration_data(TOUCH_X_AXIS)[2], 
            x_errors, 1024, &x_error_sum, xKp, xKd, xKi);
    } else if (axis == TOUCH_Y_AXIS) {
         do_pid_for_axis(TOUCH_Y_AXIS, touchscreen_read_y(), (float) touchscreen_calibration_data(TOUCH_Y_AXIS)[2], 
            y_errors, 1024, &y_error_sum, yKp, yKd, yKi);
    }
}