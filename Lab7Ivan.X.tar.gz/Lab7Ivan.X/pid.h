/* 
 * File:   pid.h
 * Author: team-6a
 *
 * Created on April 11, 2022, 9:59 PM
 */

#ifndef PID_H
#define	PID_H

#include "types.h"

void do_pid_calculation(uint8_t axis);

#endif	/* PID_H */

