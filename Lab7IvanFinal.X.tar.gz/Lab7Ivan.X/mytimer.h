/* 
 * File:   mytimer.h
 * Author: rahulav
 *
 * Created on February 2, 2022, 4:06 PM
 */

#ifndef MY_TIMER_H
#define	MY_TIMER_H

#define PERIOD_20MS 655
#define PERIOD_10MS 330

void start_timer_32hz(uint16_t);

#endif	/* TIMER_H */

